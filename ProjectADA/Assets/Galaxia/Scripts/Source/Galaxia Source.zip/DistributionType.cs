﻿// ----------------------------------------------------------------
// Galaxia
// ©2016 Simeon Radivoev
// Written by Simeon Radivoev (simeonradivoev@gmail.com)
// ----------------------------------------------------------------
namespace Galaxia
{
    public enum DistrbuitionType
    {
        Linear,
        Distance,
        Angle,
        Perlin,
        Random,
    }
}
